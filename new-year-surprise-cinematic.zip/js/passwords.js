
const page1="i want to eat your pie";
const page7="my everyTHING belongs to you";
