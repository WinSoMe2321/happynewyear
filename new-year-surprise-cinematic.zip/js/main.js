
function check(real,id,go){
let v=document.getElementById(id).value;
if(v===real){location.href=go;}else{alert("Hehe… only you can unlock this 😉");}
}
